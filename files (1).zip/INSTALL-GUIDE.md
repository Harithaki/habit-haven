# Habit Haven - Progressive Web App

Your elegant habit tracking app that works on **phone**, **tablet**, and **laptop**!

## 📱 What You Get

- **Works offline** - Use it anywhere, anytime
- **Install like a real app** - No app store needed
- **Syncs across devices** - Via export/import
- **Beautiful design** - Burgundy & cream elegance
- **Fully functional** - Habits, routines, goals, schedule, finances

---

## 🚀 HOW TO INSTALL

### Method 1: Using GitHub Pages (Recommended - Easiest!)

**Step 1: Upload to GitHub**

1. Go to [GitHub.com](https://github.com) and sign in (or create free account)
2. Click "New Repository"
3. Name it: `habit-haven`
4. Make it Public
5. Click "Create Repository"
6. Click "uploading an existing file"
7. Drag and drop these 4 files:
   - `index.html`
   - `app.js`
   - `manifest.json`
   - `service-worker.js`
8. Click "Commit changes"

**Step 2: Enable GitHub Pages**

1. In your repository, click "Settings"
2. Scroll down to "Pages" (left sidebar)
3. Under "Source", select "main" branch
4. Click "Save"
5. Wait 1-2 minutes
6. Your app will be live at: `https://YOUR-USERNAME.github.io/habit-haven/`

**Step 3: Install on Your Devices**

Now follow the instructions below based on your device!

---

### 📱 INSTALL ON IPHONE/IPAD

1. Open Safari (must use Safari!)
2. Go to your GitHub Pages URL: `https://YOUR-USERNAME.github.io/habit-haven/`
3. Tap the **Share button** (square with arrow pointing up)
4. Scroll down and tap **"Add to Home Screen"**
5. Tap **"Add"**
6. Done! App icon appears on your home screen

**To Open:**
- Tap the "Habit Haven" icon on your home screen
- It opens full-screen like a real app!

---

### 📱 INSTALL ON ANDROID PHONE

1. Open **Chrome** browser
2. Go to your GitHub Pages URL: `https://YOUR-USERNAME.github.io/habit-haven/`
3. Tap the **menu** (three dots) in top right
4. Tap **"Add to Home screen"** or **"Install app"**
5. Tap **"Install"**
6. Done! App icon appears on your home screen

**To Open:**
- Tap the "Habit Haven" icon on your home screen
- Opens like a real app!

---

### 💻 INSTALL ON WINDOWS LAPTOP

1. Open **Chrome** or **Edge** browser
2. Go to your GitHub Pages URL: `https://YOUR-USERNAME.github.io/habit-haven/`
3. Look for the **install icon** (➕ or computer icon) in the address bar
4. Click it and click **"Install"**
5. Done! App appears in your Start Menu and Desktop

**To Open:**
- Find "Habit Haven" in Start Menu
- Or double-click desktop shortcut
- Opens in its own window!

---

### 💻 INSTALL ON MAC LAPTOP

1. Open **Chrome** or **Safari** browser
2. Go to your GitHub Pages URL: `https://YOUR-USERNAME.github.io/habit-haven/`

**Chrome:**
3. Look for install icon in address bar
4. Click "Install"

**Safari:**
3. Click Safari menu → "Add to Dock"

**To Open:**
- Find "Habit Haven" in Applications or Dock
- Opens in its own window!

---

## Method 2: Local Server (For Developers)

If you want to run it locally:

```bash
# Using Python 3
python -m http.server 8000

# Or using Node.js
npx http-server

# Or using PHP
php -S localhost:8000
```

Then visit: `http://localhost:8000`

**Note:** PWA features (install, offline mode) require HTTPS, which only works with GitHub Pages or a proper web server.

---

## 🎯 USING THE APP

### Features

1. **Dashboard** - See everything at a glance
2. **Habits** - Track daily habits with streaks
3. **Routines** - Morning, Afternoon, Evening routines
4. **Goals** - Set goals with sub-tasks
5. **Schedule** - Weekly calendar with events
6. **Finances** - Track income, expenses, savings goals
7. **Progress** - View your stats and achievements
8. **Settings** - Export/import your data

### Data Sync Between Devices

Your data is stored locally on each device. To sync:

1. On Device A: Go to Settings → Export Data
2. Save the JSON file
3. On Device B: Go to Settings → Import Data
4. Select the JSON file

### Backup Your Data

**Important:** Export your data regularly!

- Settings → Export Data
- Save the JSON file somewhere safe
- Import it if you need to restore

---

## 🔧 FILES EXPLAINED

- **index.html** - The main app interface
- **app.js** - All the app logic and functionality
- **manifest.json** - PWA configuration (name, icons, colors)
- **service-worker.js** - Makes app work offline

---

## ❓ TROUBLESHOOTING

**App won't install on iPhone:**
- Make sure you're using Safari (not Chrome)
- Try refreshing the page first

**Install button doesn't appear:**
- Make sure you're using HTTPS (GitHub Pages)
- Try on a different browser
- Clear browser cache and try again

**Data disappeared:**
- Check if you're on the right device
- Data is stored per-device
- Import from your last export

**App not working offline:**
- Make sure you visited the page while online first
- Service worker needs to cache files on first visit

---

## 💎 TIPS

1. **Add to home screen first** - Best experience
2. **Export data weekly** - Don't lose your progress
3. **Use on multiple devices** - Export/import to sync
4. **Works offline** - Perfect for travel
5. **No account needed** - All data stays on your device

---

## 🎨 CUSTOMIZATION

Want to change colors? Edit in `index.html`:

- **Burgundy**: `#52131e` (main color)
- **Cream**: `#f3d9b4` (accent color)
- **Background**: `#fcf6ee` (off-white)

Want to change the name? Edit in `manifest.json`:

```json
"name": "Your App Name",
"short_name": "Short Name"
```

---

## 📝 PRIVACY

- **No tracking** - We don't collect any data
- **No ads** - Clean experience
- **No account** - No registration needed
- **All local** - Data never leaves your device (unless you export it)

---

## 🆘 NEED HELP?

**Common Issues:**

1. **Blank screen?** - Hard refresh (Ctrl+Shift+R on PC, Cmd+Shift+R on Mac)
2. **Features not working?** - Make sure JavaScript is enabled
3. **Can't add habits?** - Check browser console for errors
4. **Lost data?** - Import from your last export

---

## 🎉 YOU'RE ALL SET!

Enjoy your elegant habit tracking experience! 

Remember to export your data regularly to keep it safe. 💎
