// Habit Haven - Application Logic

// Data storage
let appData = {
  habits: [],
  routines: {
    morning: [],
    afternoon: [],
    evening: []
  },
  goals: [],
  schedule: [],
  finances: {
    transactions: [],
    savingsGoals: []
  }
};

let currentRoutineTab = 'morning';
let editingRoutineId = null;

// Load data from localStorage
function loadData() {
  const saved = localStorage.getItem('habitHavenData');
  if (saved) {
    try {
      appData = JSON.parse(saved);
      if (!appData.routines) appData.routines = { morning: [], afternoon: [], evening: [] };
      if (!appData.goals) appData.goals = [];
      if (!appData.schedule) appData.schedule = [];
      if (!appData.finances) appData.finances = { transactions: [], savingsGoals: [] };
    } catch (e) {
      console.error('Error loading data:', e);
    }
  }
}

// Save data to localStorage
function saveData() {
  localStorage.setItem('habitHavenData', JSON.stringify(appData));
}

// Get today's date
function getToday() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

// Get time of day
function getTimeOfDay() {
  const hour = new Date().getHours();
  if (hour < 12) return 'morning';
  if (hour < 17) return 'afternoon';
  return 'evening';
}

// Format currency
function formatCurrency(amount) {
  return '$' + parseFloat(amount || 0).toFixed(2);
}

// Switch view
function switchView(viewName) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  
  document.getElementById('view-' + viewName).classList.add('active');
  document.querySelector(`.nav-btn[data-view="${viewName}"]`).classList.add('active');
  
  render();
}

// Modal functions
function openModal(modalId) {
  document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('active');
  document.querySelectorAll('#' + modalId + ' input, #' + modalId + ' select, #' + modalId + ' textarea').forEach(input => {
    if (input.type === 'checkbox') input.checked = false;
    else input.value = '';
  });
}

// Toggle habit
function toggleHabit(habitId) {
  const today = getToday();
  const habit = appData.habits.find(h => h.id === habitId);
  if (!habit) return;
  if (!habit.completedDates) habit.completedDates = [];
  
  const index = habit.completedDates.indexOf(today);
  if (index > -1) {
    habit.completedDates.splice(index, 1);
    habit.streak = Math.max(0, (habit.streak || 0) - 1);
  } else {
    habit.completedDates.push(today);
    habit.streak = (habit.streak || 0) + 1;
  }
  saveData();
  render();
}

// Add habit
function addHabit() {
  const name = prompt('Enter habit name:');
  if (name && name.trim()) {
    appData.habits.push({
      id: Date.now(),
      name: name.trim(),
      completedDates: [],
      streak: 0,
      frequency: 'daily'
    });
    saveData();
    render();
  }
}

// Delete habit
function deleteHabit(habitId) {
  if (confirm('Delete this habit?')) {
    appData.habits = appData.habits.filter(h => h.id !== habitId);
    saveData();
    render();
  }
}

// Routines
function switchRoutineTab(tabName) {
  currentRoutineTab = tabName;
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelector(`.tab[data-routine="${tabName}"]`).classList.add('active');
  renderRoutines();
}

function addRoutineStep() {
  openModal('routineModal');
  editingRoutineId = null;
}

function saveRoutineStep() {
  const step = document.getElementById('routineStepInput').value.trim();
  const time = document.getElementById('routineTimeInput').value;
  
  if (!step) return;

  if (editingRoutineId) {
    const routine = appData.routines[currentRoutineTab].find(r => r.id === editingRoutineId);
    if (routine) {
      routine.task = step;
      routine.time = time;
    }
  } else {
    appData.routines[currentRoutineTab].push({
      id: Date.now(),
      task: step,
      time: time
    });
  }
  
  saveData();
  closeModal('routineModal');
  render();
}

function deleteRoutineStep(id) {
  if (confirm('Delete this step?')) {
    appData.routines[currentRoutineTab] = appData.routines[currentRoutineTab].filter(r => r.id !== id);
    saveData();
    render();
  }
}

// Goals
function addGoal() {
  openModal('goalModal');
}

function saveGoal() {
  const title = document.getElementById('goalTitleInput').value.trim();
  const targetDate = document.getElementById('goalDateInput').value;
  const category = document.getElementById('goalCategoryInput').value;
  
  if (!title) return;

  appData.goals.push({
    id: Date.now(),
    title: title,
    targetDate: targetDate,
    category: category,
    subTasks: [],
    completed: false
  });
  
  saveData();
  closeModal('goalModal');
  render();
}

function deleteGoal(goalId) {
  if (confirm('Delete this goal?')) {
    appData.goals = appData.goals.filter(g => g.id !== goalId);
    saveData();
    render();
  }
}

function addSubTask(goalId) {
  const task = prompt('Enter sub-task:');
  if (task && task.trim()) {
    const goal = appData.goals.find(g => g.id === goalId);
    if (goal) {
      if (!goal.subTasks) goal.subTasks = [];
      goal.subTasks.push({
        id: Date.now(),
        description: task.trim(),
        completed: false
      });
      saveData();
      render();
    }
  }
}

function toggleSubTask(goalId, taskId) {
  const goal = appData.goals.find(g => g.id === goalId);
  if (goal && goal.subTasks) {
    const task = goal.subTasks.find(t => t.id === taskId);
    if (task) {
      task.completed = !task.completed;
      saveData();
      render();
    }
  }
}

// Schedule
function addEvent() {
  openModal('eventModal');
  document.getElementById('eventDateInput').value = getToday();
}

function saveEvent() {
  const title = document.getElementById('eventTitleInput').value.trim();
  const day = parseInt(document.getElementById('eventDayInput').value);
  const startTime = document.getElementById('eventStartInput').value;
  const endTime = document.getElementById('eventEndInput').value;
  
  if (!title) return;

  appData.schedule.push({
    id: Date.now(),
    title: title,
    day: day,
    startTime: startTime,
    endTime: endTime
  });
  
  saveData();
  closeModal('eventModal');
  render();
}

function deleteEvent(eventId) {
  if (confirm('Delete this event?')) {
    appData.schedule = appData.schedule.filter(e => e.id !== eventId);
    saveData();
    render();
  }
}

// Finances
function addTransaction() {
  openModal('transactionModal');
  document.getElementById('transactionDateInput').value = getToday();
}

function saveTransaction() {
  const type = document.getElementById('transactionTypeInput').value;
  const amount = parseFloat(document.getElementById('transactionAmountInput').value);
  const category = document.getElementById('transactionCategoryInput').value.trim();
  const description = document.getElementById('transactionDescInput').value.trim();
  const date = document.getElementById('transactionDateInput').value;
  
  if (!amount || !category) return;

  appData.finances.transactions.push({
    id: Date.now(),
    type: type,
    amount: amount,
    category: category,
    description: description,
    date: date
  });
  
  saveData();
  closeModal('transactionModal');
  render();
}

function deleteTransaction(transactionId) {
  if (confirm('Delete this transaction?')) {
    appData.finances.transactions = appData.finances.transactions.filter(t => t.id !== transactionId);
    saveData();
    render();
  }
}

function addSavingsGoal() {
  openModal('savingsGoalModal');
}

function saveSavingsGoal() {
  const name = document.getElementById('savingsGoalNameInput').value.trim();
  const targetAmount = parseFloat(document.getElementById('savingsGoalAmountInput').value);
  const currentAmount = parseFloat(document.getElementById('savingsGoalCurrentInput').value) || 0;
  const deadline = document.getElementById('savingsGoalDeadlineInput').value;
  
  if (!name || !targetAmount) return;

  appData.finances.savingsGoals.push({
    id: Date.now(),
    name: name,
    targetAmount: targetAmount,
    currentAmount: currentAmount,
    deadline: deadline
  });
  
  saveData();
  closeModal('savingsGoalModal');
  render();
}

function deleteSavingsGoal(goalId) {
  if (confirm('Delete this savings goal?')) {
    appData.finances.savingsGoals = appData.finances.savingsGoals.filter(g => g.id !== goalId);
    saveData();
    render();
  }
}

// Export/Reset
function exportData() {
  const dataStr = JSON.stringify(appData, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'habit-haven-' + getToday() + '.json';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
  alert('Data exported successfully!');
}

function resetData() {
  if (confirm('This will DELETE ALL your data. Are you sure?')) {
    if (confirm('Last chance! Click OK to permanently delete everything.')) {
      appData = {
        habits: [],
        routines: { morning: [], afternoon: [], evening: [] },
        goals: [],
        schedule: [],
        finances: { transactions: [], savingsGoals: [] }
      };
      saveData();
      render();
      alert('All data has been reset.');
    }
  }
}

// Render functions
function render() {
  renderDashboard();
  renderHabits();
  renderRoutines();
  renderGoals();
  renderSchedule();
  renderFinances();
  renderProgress();
}

function renderDashboard() {
  const today = getToday();
  document.getElementById('timeOfDay').textContent = getTimeOfDay();
  
  const quotes = ['Excellence is a habit', 'Small steps lead to great change', 'Consistency breeds success', 'Today is an opportunity', 'Progress over perfection'];
  document.getElementById('quote').textContent = quotes[new Date().getDay() % quotes.length];

  const todayHabits = appData.habits.filter(h => h.frequency === 'daily');
  const completedToday = todayHabits.filter(h => h.completedDates && h.completedDates.includes(today)).length;
  const longestStreak = Math.max(0, ...appData.habits.map(h => h.streak || 0));

  document.getElementById('todayProgress').textContent = `${completedToday}/${todayHabits.length}`;
  document.getElementById('streak').textContent = longestStreak;

  const totalIncome = appData.finances.transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = appData.finances.transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  
  document.getElementById('balance').textContent = formatCurrency(totalIncome - totalExpenses);

  const primaryGoal = appData.finances.savingsGoals[0];
  if (primaryGoal) {
    const progress = Math.round((primaryGoal.currentAmount / primaryGoal.targetAmount) * 100);
    document.getElementById('savings').textContent = progress + '%';
  } else {
    document.getElementById('savings').textContent = '0%';
  }

  const habitsList = document.getElementById('habitsList');
  if (todayHabits.length === 0) {
    habitsList.innerHTML = '<div class="empty"><p>No habits yet</p><button class="btn" onclick="switchView(\'habits\'); setTimeout(addHabit, 100);">Create First Habit</button></div>';
  } else {
    let html = '';
    todayHabits.forEach(habit => {
      const isCompleted = habit.completedDates && habit.completedDates.includes(today);
      html += `
        <div class="habit-item">
          <div class="checkbox ${isCompleted ? 'checked' : ''}" onclick="toggleHabit(${habit.id})">${isCompleted ? '✓' : ''}</div>
          <div class="habit-name ${isCompleted ? 'completed' : ''}">${habit.name}</div>
          ${habit.streak > 0 ? `<span class="streak">${habit.streak} days</span>` : ''}
        </div>
      `;
    });
    habitsList.innerHTML = html;
  }
}

function renderHabits() {
  const today = getToday();
  const allHabits = document.getElementById('allHabits');
  if (appData.habits.length === 0) {
    allHabits.innerHTML = '<div class="empty"><p>No habits created yet</p><button class="btn" onclick="addHabit()">Create First Habit</button></div>';
  } else {
    let html = '';
    appData.habits.forEach(habit => {
      const isCompleted = habit.completedDates && habit.completedDates.includes(today);
      html += `
        <div class="habit-item">
          <div class="checkbox ${isCompleted ? 'checked' : ''}" onclick="toggleHabit(${habit.id})">${isCompleted ? '✓' : ''}</div>
          <div class="habit-name ${isCompleted ? 'completed' : ''}">${habit.name}</div>
          ${habit.streak > 0 ? `<span class="streak">${habit.streak} days</span>` : ''}
          <button class="btn btn-small" onclick="deleteHabit(${habit.id})">Delete</button>
        </div>
      `;
    });
    allHabits.innerHTML = html;
  }
}

function renderRoutines() {
  const routineSteps = document.getElementById('routineSteps');
  const steps = appData.routines[currentRoutineTab];
  
  if (steps.length === 0) {
    routineSteps.innerHTML = '<div class="empty"><p>No steps in this routine yet</p></div>';
  } else {
    let html = '';
    steps.forEach(step => {
      html += `
        <div class="routine-item">
          <div class="routine-task">${step.task}</div>
          ${step.time ? `<span style="margin-right: 15px; color: #666;">${step.time}</span>` : ''}
          <button class="btn btn-small" onclick="deleteRoutineStep(${step.id})">Delete</button>
        </div>
      `;
    });
    routineSteps.innerHTML = html;
  }
}

function renderGoals() {
  const goalsList = document.getElementById('goalsList');
  if (appData.goals.length === 0) {
    goalsList.innerHTML = '<div class="empty"><p>No goals set yet</p><button class="btn" onclick="addGoal()">Create First Goal</button></div>';
  } else {
    let html = '';
    appData.goals.forEach(goal => {
      const totalTasks = goal.subTasks ? goal.subTasks.length : 0;
      const completedTasks = goal.subTasks ? goal.subTasks.filter(t => t.completed).length : 0;
      const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
      
      html += `
        <div style="margin-bottom: 30px; padding: 20px; background: #fbeef1; border-radius: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
            <div>
              <h3 style="color: #52131e; margin-bottom: 5px;">${goal.title}</h3>
              ${goal.targetDate ? `<p style="font-size: 0.9em; color: #666;">Target: ${new Date(goal.targetDate).toLocaleDateString()}</p>` : ''}
            </div>
            <button class="btn btn-small" onclick="deleteGoal(${goal.id})">Delete</button>
          </div>
          
          ${totalTasks > 0 ? `
            <div style="margin: 15px 0;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                <span>Progress</span>
                <span style="font-weight: bold; color: #52131e;">${Math.round(progress)}%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill" style="width: ${progress}%;"></div>
              </div>
            </div>
            
            <div>
              ${goal.subTasks.map(task => `
                <div class="habit-item" style="border: none; padding: 10px 0;">
                  <div class="checkbox ${task.completed ? 'checked' : ''}" onclick="toggleSubTask(${goal.id}, ${task.id})">${task.completed ? '✓' : ''}</div>
                  <div class="habit-name ${task.completed ? 'completed' : ''}">${task.description}</div>
                </div>
              `).join('')}
            </div>
          ` : ''}
          
          <button class="btn btn-small btn-secondary" onclick="addSubTask(${goal.id})" style="margin-top: 10px;">Add Sub-task</button>
        </div>
      `;
    });
    goalsList.innerHTML = html;
  }
}

function renderSchedule() {
  const calendar = document.getElementById('calendar');
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const today = new Date().getDay();
  
  let html = '';
  for (let i = 0; i < 7; i++) {
    const dayEvents = appData.schedule.filter(e => e.day === i);
    const isToday = i === today;
    
    html += `
      <div class="day-card ${isToday ? 'today' : ''}">
        <div class="day-header">${days[i]}</div>
        ${dayEvents.length === 0 ? '<p style="color: #999; text-align: center; margin-top: 20px; font-size: 0.9em;">No events</p>' : ''}
        ${dayEvents.map(event => `
          <div class="event" onclick="deleteEvent(${event.id})">
            <div style="font-weight: bold;">${event.title}</div>
            <div style="font-size: 0.85em; margin-top: 3px;">${event.startTime} - ${event.endTime}</div>
          </div>
        `).join('')}
      </div>
    `;
  }
  calendar.innerHTML = html;
}

function renderFinances() {
  const totalIncome = appData.finances.transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = appData.finances.transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  
  document.getElementById('totalIncome').textContent = formatCurrency(totalIncome);
  document.getElementById('totalExpenses').textContent = formatCurrency(totalExpenses);
  document.getElementById('netBalance').textContent = formatCurrency(totalIncome - totalExpenses);

  const transactionsList = document.getElementById('transactionsList');
  if (appData.finances.transactions.length === 0) {
    transactionsList.innerHTML = '<div class="empty"><p>No transactions yet</p></div>';
  } else {
    const sorted = [...appData.finances.transactions].sort((a, b) => new Date(b.date) - new Date(a.date));
    let html = '';
    sorted.forEach(t => {
      html += `
        <div class="transaction-item">
          <div style="flex: 1;">
            <div style="font-weight: bold; margin-bottom: 3px;">${t.description || t.category}</div>
            <div style="font-size: 0.85em; color: #666;">
              <span class="${t.type === 'income' ? 'badge-income' : 'badge-expense'}">${t.type}</span>
              <span style="margin-left: 10px;">${t.category}</span>
              <span style="margin-left: 10px;">${new Date(t.date).toLocaleDateString()}</span>
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 1.2em; font-weight: bold; color: ${t.type === 'income' ? '#15803d' : '#b91c1c'};">
              ${t.type === 'income' ? '+' : '-'}${formatCurrency(t.amount)}
            </div>
            <button class="btn btn-small" style="margin-top: 5px;" onclick="deleteTransaction(${t.id})">Delete</button>
          </div>
        </div>
      `;
    });
    transactionsList.innerHTML = html;
  }

  const savingsGoalsList = document.getElementById('savingsGoalsList');
  if (appData.finances.savingsGoals.length === 0) {
    savingsGoalsList.innerHTML = '<div class="empty"><p>No savings goals yet</p></div>';
  } else {
    let html = '';
    appData.finances.savingsGoals.forEach(goal => {
      const progress = (goal.currentAmount / goal.targetAmount) * 100;
      const remaining = goal.targetAmount - goal.currentAmount;
      
      html += `
        <div style="margin-bottom: 20px; padding: 20px; background: #fbeef1; border-radius: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
            <div>
              <h3 style="color: #52131e; margin-bottom: 5px;">${goal.name}</h3>
              ${goal.deadline ? `<p style="font-size: 0.9em; color: #666;">Deadline: ${new Date(goal.deadline).toLocaleDateString()}</p>` : ''}
            </div>
            <button class="btn btn-small" onclick="deleteSavingsGoal(${goal.id})">Delete</button>
          </div>
          
          <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
            <span>${formatCurrency(goal.currentAmount)}</span>
            <span style="font-weight: bold; color: #52131e;">${Math.round(progress)}%</span>
          </div>
          
          <div class="progress-bar">
            <div class="progress-fill" style="width: ${Math.min(progress, 100)}%;"></div>
          </div>
          
          <div style="display: flex; justify-content: space-between; margin-top: 5px; font-size: 0.9em; color: #666;">
            <span>Target: ${formatCurrency(goal.targetAmount)}</span>
            <span>${formatCurrency(remaining)} to go</span>
          </div>
        </div>
      `;
    });
    savingsGoalsList.innerHTML = html;
  }
}

function renderProgress() {
  const progressStats = document.getElementById('progressStats');
  const totalHabits = appData.habits.length;
  const totalGoals = appData.goals.length;
  const completedGoals = appData.goals.filter(g => {
    const totalTasks = g.subTasks ? g.subTasks.length : 0;
    const completedTasks = g.subTasks ? g.subTasks.filter(t => t.completed).length : 0;
    return totalTasks > 0 && completedTasks === totalTasks;
  }).length;
  const longestStreak = Math.max(0, ...appData.habits.map(h => h.streak || 0));

  progressStats.innerHTML = `
    <div class="stats">
      <div class="stat-card">
        <div class="stat-number">${totalHabits}</div>
        <div class="stat-label">Total Habits</div>
      </div>
      <div class="stat-card">
        <div class="stat-number">${longestStreak}</div>
        <div class="stat-label">Longest Streak</div>
      </div>
      <div class="stat-card">
        <div class="stat-number">${completedGoals}/${totalGoals}</div>
        <div class="stat-label">Goals Completed</div>
      </div>
      <div class="stat-card">
        <div class="stat-number">${appData.schedule.length}</div>
        <div class="stat-label">Scheduled Events</div>
      </div>
    </div>
  `;
}

// Initialize app
function init() {
  loadData();
  render();

  // Nav buttons
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      switchView(this.getAttribute('data-view'));
    });
  });

  // Routine tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', function() {
      switchRoutineTab(this.getAttribute('data-routine'));
    });
  });

  // Button event listeners
  document.getElementById('addHabitBtn').addEventListener('click', addHabit);
  document.getElementById('addRoutineBtn').addEventListener('click', addRoutineStep);
  document.getElementById('addGoalBtn').addEventListener('click', addGoal);
  document.getElementById('addEventBtn').addEventListener('click', addEvent);
  document.getElementById('addTransactionBtn').addEventListener('click', addTransaction);
  document.getElementById('addSavingsGoalBtn').addEventListener('click', addSavingsGoal);
  document.getElementById('exportBtn').addEventListener('click', exportData);
  document.getElementById('resetBtn').addEventListener('click', resetData);

  // Modal save buttons
  document.getElementById('saveRoutineBtn').addEventListener('click', saveRoutineStep);
  document.getElementById('saveGoalBtn').addEventListener('click', saveGoal);
  document.getElementById('saveEventBtn').addEventListener('click', saveEvent);
  document.getElementById('saveTransactionBtn').addEventListener('click', saveTransaction);
  document.getElementById('saveSavingsGoalBtn').addEventListener('click', saveSavingsGoal);
}

// Start app when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
